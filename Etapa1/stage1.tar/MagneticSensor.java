public class MagneticSensor extends Sensor {
    public MagneticSensor(){}
    public void moveMagnetAwayFromSwitch() {
        setState(....);
    }
    public void putMagnetNearSwitch() {
        ....
    }
}
