public enum State {
    CLOSE,
    OPEN
}
